
# Media Copyright Query Resolution Agent

## 📌 Overview
This project is built for the TCS AI Fridays Hackathon.  
It answers any copyright-related question using AI.

## 🚀 Features
- Loads copyright laws, company rules, and license policies.
- Searches relevant information using embeddings.
- Provides simple, clear copyright answers.
- Recommends actions (license, permission, alternatives).

## 📂 Project Structure
```
/docs               → All text documents (copyright, policy, rules)
/ingest.py          → Converts docs into searchable chunks + builds index
/retriever.py       → Finds best matching information
/generator.py       → AI answer generator
/app.py             → Flask API endpoint
/requirements.txt
```

## ▶️ How to Run
1. Install requirements:
```
pip install -r requirements.txt
```

2. Build index:
```
python ingest.py
```

3. Start the app:
```
python app.py
```

4. Ask a question:
```
POST http://localhost:8080/ask
{
  "question": "Can I use 20 seconds of a song in a YouTube video?"
}
```

## 🎯 Expected Output
- Simple explanation
- Allowed / Not allowed
- What the user should do next
- Sources used

## 📝 Disclaimer
This system gives guidance, not legal advice.
