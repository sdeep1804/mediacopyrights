# retriever.py
import json, faiss
import numpy as np
from sentence_transformers import SentenceTransformer

class Retriever:
    def __init__(self,index_path,meta_path):
        self.index=faiss.read_index(index_path)
        with open(meta_path,"r") as f:
            data=json.load(f)
        self.texts=data["texts"]
        self.meta=data["metadata"]
        self.model=SentenceTransformer("sentence-transformers/all-mpnet-base-v2")

    def query(self,q,k=5):
        emb=self.model.encode([q], convert_to_numpy=True, normalize_embeddings=True).astype("float32")
        D,I=self.index.search(emb,k)
        results=[]
        for idx,score in zip(I[0],D[0]):
            results.append({"text":self.texts[idx],"score":float(score),"meta":self.meta[idx]})
        return results
