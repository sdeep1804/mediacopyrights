# app.py
from flask import Flask, request, jsonify
from retriever import Retriever
from generator import generate_answer

app=Flask(__name__)
retriever=Retriever("copyright.index","meta.json")

@app.route("/ask", methods=["POST"])
def ask():
    q=request.json.get("question")
    hits=retriever.query(q)
    ans=generate_answer(q,hits)
    return jsonify({"answer":ans,"sources":hits})

if __name__=="__main__":
    app.run(port=8080)
