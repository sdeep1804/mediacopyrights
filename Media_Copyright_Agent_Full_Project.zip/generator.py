# generator.py
from openai import OpenAI
from dotenv import load_dotenv
import os
load_dotenv()
client = OpenAI()

def generate_answer(question, retrieved):
    passages=""
    for r in retrieved:
        passages+=f"[{r['meta']['source']} - chunk {r['meta']['chunk']}] {r['text']}

"

    prompt=f""You are a simple copyright assistant.
Use the information below and answer clearly.

Information:
{passages}

Question: {question}

Answer format:
- Simple explanation
- Allowed or not
- What the user should do next
"""

    response=client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"user","content":prompt}]
    )

    return response.choices[0].message.content
