# ingest.py
import os
from pathlib import Path
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import nltk
nltk.download('punkt')
from nltk.tokenize import sent_tokenize

def read_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def chunk_text(text, max_chars=1000):
    sentences = sent_tokenize(text)
    chunks = []
    current=""
    for s in sentences:
        if len(current)+len(s)<=max_chars:
            current+=s+" "
        else:
            chunks.append(current.strip())
            current=s+" "
    if current.strip():
        chunks.append(current.strip())
    return chunks

def build_index(input_dir="docs", index_path="copyright.index", meta_path="meta.json"):
    model = SentenceTransformer("sentence-transformers/all-mpnet-base-v2")
    texts=[]
    metadata=[]

    for p in Path(input_dir).glob("*.txt"):
        content=read_file(p)
        chunks=chunk_text(content)
        for i,ch in enumerate(chunks):
            texts.append(ch)
            metadata.append({"source":str(p),"chunk":i})

    embeddings=model.encode(texts, convert_to_numpy=True, normalize_embeddings=True)
    dim=embeddings.shape[1]
    index=faiss.IndexFlatIP(dim)
    index.add(embeddings.astype("float32"))
    faiss.write_index(index, index_path)

    import json
    with open(meta_path,"w") as f:
        json.dump({"texts":texts,"metadata":metadata}, f)

if __name__=="__main__":
    build_index()
